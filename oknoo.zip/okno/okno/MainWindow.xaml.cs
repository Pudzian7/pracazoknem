﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace okno
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int x = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton != null)
            {
                string optionText = radioButton.Content.ToString();
                switch (optionText)
                {
                    case "Opcja 1":
                        Text2.Foreground = Brushes.Orange;
                        Text2.Text = "Wybrano 1";
                        break;
                    case "Opcja 2":
                        Text2.Foreground = Brushes.DarkRed;
                        Text2.Text = "Wybrano 2";
                        break;
                    case "Opcja 3":
                        Text2.Foreground = Brushes.DarkGray;
                        Text2.Text = "Wybrano 3";
                        break;
                }
            }
        }
        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            if (x == 0)
            {
                img2.Source = new BitmapImage(new Uri("góry1.jpg", UriKind.Relative)); x = 0;
            }
            else
            {
                img2.Source = new BitmapImage(new Uri("góry2.jpg", UriKind.Relative)); x = 1;
            }
        }
    }
}
